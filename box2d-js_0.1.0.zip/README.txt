How to use
1. put js/ and lib/ in your app dir
2. add script tags refering the header of index.html
